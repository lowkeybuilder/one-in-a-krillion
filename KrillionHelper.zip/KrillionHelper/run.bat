@echo off
py krillion_helper.py
if errorlevel 1 pause
