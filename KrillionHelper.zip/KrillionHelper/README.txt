NEEDED:
-----------------

mss>=9.0.1
Pillow>=10.0.0
pytesseract>=0.3.10
==========================================================================================================================================


╔══════════════════════════════════════════╗
║                                                       ║
║                 ONE IN A KRILLION                     ║
║                  SETUP UTILITY                        ║
║                                                       ║
║                DEPENDENCY INSTALLER                   ║
║                                                       ║
╚══════════════════════════════════════════╝

 [1] INSTALL PYTHON
 ──────────────────────────────────────────
 Open PowerShell and paste:

 "winget install --id Python.Python.3.14 -e"


 [2] INSTALL TESSERACT OCR
 ──────────────────────────────────────────

 "winget install --id UB-Mannheim.TesseractOCR -e"


 [3] REOPEN POWERSHELL
 ──────────────────────────────────────────
 Close PowerShell and open it again.


 [4] INSTALL REQUIRED PACKAGES
 ──────────────────────────────────────────

 "py -m pip install --upgrade mss Pillow pytesseract"

╔══════════════════════════════════════════╗
║               INSTALLATION COMPLETE                   ║
║                                                       ║
║                ONE IN A KRILLION                      ║
╚══════════════════════════════════════════╝

Open One in a Krillion and try it out!