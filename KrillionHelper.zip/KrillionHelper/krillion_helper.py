import json
import os
import re
import sqlite3
import threading
import urllib.request
import tkinter as tk
from tkinter import ttk, messagebox
from difflib import SequenceMatcher
from datetime import datetime

APP_NAME = "Krillion Helper"
DB_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "krillion_answers.db")
DATA_URL = "https://raw.githubusercontent.com/StruggleYang/krillion-dataset/main/data/krillion_dives.json"
TIER_POINTS = {
    "Plankton": 10,
    "Too Clever": 15,
    "Schooler": 30,
    "Rare": 60,
    "Deep Cut": 85,
    "One in a Krillion": 100,
}
TIER_ORDER = {name: i for i, name in enumerate(TIER_POINTS)}

def normalize(value):
    value = (value or "").casefold()
    value = re.sub(r"[^a-z0-9\s'-]", " ", value)
    return " ".join(value.split())

def connect_db():
    conn = sqlite3.connect(DB_FILE)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS prompts (
            id INTEGER PRIMARY KEY,
            dive_number INTEGER,
            date TEXT,
            prompt_number INTEGER,
            prompt TEXT,
            accepted_count INTEGER DEFAULT 0
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS answers (
            id INTEGER PRIMARY KEY,
            prompt_id INTEGER,
            answer TEXT,
            tier TEXT,
            points INTEGER,
            FOREIGN KEY(prompt_id) REFERENCES prompts(id)
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_prompt_text ON prompts(prompt)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_answer_text ON answers(answer)")
    conn.commit()
    return conn

def import_dataset(path, status_callback=None):
    with open(path, "r", encoding="utf-8") as f:
        dives = json.load(f)
    conn = connect_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM answers")
    cur.execute("DELETE FROM prompts")
    prompt_total = answer_total = 0
    for dive in dives:
        dive_no = dive.get("n")
        date = dive.get("date", "")
        for p_no, prompt in enumerate(dive.get("prompts", []), 1):
            cur.execute(
                "INSERT INTO prompts(dive_number,date,prompt_number,prompt,accepted_count) VALUES(?,?,?,?,?)",
                (dive_no, date, p_no, prompt.get("q", ""), prompt.get("accepted", 0))
            )
            pid = cur.lastrowid
            prompt_total += 1
            for tier in prompt.get("tiers", []):
                tier_name = tier.get("name", "")
                points = TIER_POINTS.get(tier_name, 0)
                for answer in tier.get("picks", []):
                    if answer and points:
                        cur.execute(
                            "INSERT INTO answers(prompt_id,answer,tier,points) VALUES(?,?,?,?)",
                            (pid, answer, tier_name, points)
                        )
                        answer_total += 1
    conn.commit()
    conn.close()
    return len(dives), prompt_total, answer_total

def db_stats():
    conn = connect_db()
    cur = conn.cursor()
    dives = cur.execute("SELECT COUNT(DISTINCT dive_number) FROM prompts").fetchone()[0]
    prompts = cur.execute("SELECT COUNT(*) FROM prompts").fetchone()[0]
    answers = cur.execute("SELECT COUNT(*) FROM answers").fetchone()[0]
    latest = cur.execute("SELECT MAX(date) FROM prompts").fetchone()[0]
    conn.close()
    return dives, prompts, answers, latest

def score_prompt_similarity(query, candidate):
    qn, cn = normalize(query), normalize(candidate)
    if not qn or not cn:
        return 0.0
    if qn == cn:
        return 1.0
    seq = SequenceMatcher(None, qn, cn).ratio()
    qt, ct = set(qn.split()), set(cn.split())
    overlap = len(qt & ct) / max(1, len(qt | ct))
    # Prefer shared specific words while still allowing wording changes.
    return max(seq, overlap * 0.92)

def find_candidates(query, limit=12):
    conn = connect_db()
    rows = conn.execute("""
        SELECT p.id,p.dive_number,p.date,p.prompt,p.accepted_count,
               a.answer,a.tier,a.points
        FROM prompts p JOIN answers a ON a.prompt_id=p.id
    """).fetchall()
    conn.close()
    scored = []
    for row in rows:
        pid, dive, date, old_prompt, accepted, answer, tier, points = row
        sim = score_prompt_similarity(query, old_prompt)
        if sim >= 0.18:
            scored.append({
                "answer": answer, "tier": tier, "points": points,
                "prompt": old_prompt, "similarity": sim,
                "date": date, "dive": dive, "accepted": accepted
            })
    # Prefer similarity first, then original tier score.
    scored.sort(key=lambda x: (x["similarity"], x["points"]), reverse=True)

    # Deduplicate answer spellings, keeping strongest matching context.
    result, seen = [], set()
    for item in scored:
        key = normalize(item["answer"])
        if key in seen:
            continue
        seen.add(key)
        result.append(item)
        if len(result) >= limit:
            break
    return result

class KrillionApp:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_NAME)
        self.root.geometry("820x700")
        self.root.minsize(650, 570)
        self.root.configure(bg="#10141d")
        self.root.attributes("-topmost", True)
        self._setup_style()

        outer = ttk.Frame(root, padding=18)
        outer.pack(fill="both", expand=True)

        header = ttk.Frame(outer)
        header.pack(fill="x")
        ttk.Label(header, text="KRILLION HELPER", style="Header.TLabel").pack(side="left")
        self.topmost_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(header, text="Stay on top", variable=self.topmost_var,
                        command=self.toggle_topmost).pack(side="right")

        ttk.Label(
            outer,
            text="Offline answer finder · no AI · searches recorded Krillion answer sheets",
            style="Sub.TLabel"
        ).pack(anchor="w", pady=(3, 16))

        ttk.Label(outer, text="CURRENT GAME PROMPT", style="Section.TLabel").pack(anchor="w")
        self.prompt = tk.Text(
            outer, height=4, wrap="word", font=("Segoe UI", 12),
            bg="#1b2331", fg="#f1f5f9", insertbackground="white",
            relief="flat", padx=10, pady=9
        )
        self.prompt.pack(fill="x", pady=(6, 9))

        actions = ttk.Frame(outer)
        actions.pack(fill="x", pady=(0, 14))
        ttk.Button(actions, text="Find answers", style="Accent.TButton",
                   command=self.search).pack(side="left")
        ttk.Button(actions, text="Scan prompt area (OCR)",
                   command=self.scan_screen).pack(side="left", padx=8)
        ttk.Button(actions, text="Update database",
                   command=self.update_database).pack(side="left")
        ttk.Button(actions, text="Clear", command=self.clear).pack(side="right")

        ttk.Label(outer, text="BEST MATCHES", style="Section.TLabel").pack(anchor="w")
        self.result = tk.Text(
            outer, height=18, wrap="word", font=("Segoe UI", 10),
            bg="#1b2331", fg="#e5e7eb", insertbackground="white",
            relief="flat", padx=12, pady=10
        )
        self.result.pack(fill="both", expand=True, pady=(6, 9))
        self.result.tag_configure("best", foreground="#75e0ad", font=("Segoe UI", 11, "bold"))
        self.result.tag_configure("tier", foreground="#f7c873", font=("Segoe UI", 9, "bold"))
        self.result.tag_configure("muted", foreground="#9aa7b8", font=("Segoe UI", 9))

        bottom = ttk.Frame(outer)
        bottom.pack(fill="x")
        ttk.Button(bottom, text="Copy top answer", command=self.copy_top).pack(side="left")
        self.status = tk.StringVar(value="Database not checked yet.")
        ttk.Label(bottom, textvariable=self.status, style="Sub.TLabel").pack(side="left", padx=12)

        self.root.bind("<Control-Return>", lambda e: self.search())
        self.root.bind("<Control-Shift-K>", lambda e: self.scan_screen())
        self.refresh_stats()

    def _setup_style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure(".", background="#10141d", foreground="#e5e7eb",
                        font=("Segoe UI", 9))
        style.configure("TFrame", background="#10141d")
        style.configure("TLabel", background="#10141d", foreground="#e5e7eb")
        style.configure("Header.TLabel", font=("Segoe UI", 19, "bold"),
                        foreground="#f8fafc", background="#10141d")
        style.configure("Sub.TLabel", foreground="#9aa7b8", background="#10141d")
        style.configure("Section.TLabel", font=("Segoe UI", 9, "bold"),
                        foreground="#8ba4c7", background="#10141d")
        style.configure("TButton", padding=(10, 7), background="#293548",
                        foreground="#f8fafc", borderwidth=0)
        style.map("TButton", background=[("active", "#3a4b63")])
        style.configure("Accent.TButton", background="#176b50",
                        foreground="white", font=("Segoe UI", 9, "bold"))
        style.map("Accent.TButton", background=[("active", "#21835f")])
        style.configure("TCheckbutton", background="#10141d", foreground="#cbd5e1")

    def toggle_topmost(self):
        self.root.attributes("-topmost", self.topmost_var.get())

    def refresh_stats(self):
        try:
            dives, prompts, answers, latest = db_stats()
            if prompts:
                self.status.set(f"{dives} dives · {prompts} prompts · {answers:,} sample answers · latest {latest}")
            else:
                self.status.set("Database empty. Click Update database to download the public dataset.")
        except Exception as exc:
            self.status.set("Database status unavailable: " + str(exc))

    def update_database(self):
        self.status.set("Downloading public historical dataset...")
        threading.Thread(target=self._download_worker, daemon=True).start()

    def _download_worker(self):
        tmp = os.path.join(os.path.dirname(DB_FILE), "krillion_dataset_download.json")
        try:
            req = urllib.request.Request(DATA_URL, headers={"User-Agent": "KrillionHelper/1.0"})
            with urllib.request.urlopen(req, timeout=60) as response, open(tmp, "wb") as out:
                out.write(response.read())
            dives, prompts, answers = import_dataset(tmp)
            try:
                os.remove(tmp)
            except OSError:
                pass
            self.root.after(0, lambda: self._updated(dives, prompts, answers))
        except Exception as exc:
            self.root.after(0, lambda: self.status.set("Update failed: " + str(exc)))

    def _updated(self, dives, prompts, answers):
        self.refresh_stats()
        messagebox.showinfo(
            "Database updated",
            f"Imported {dives} dives, {prompts} prompts and {answers:,} sample answers.\n\n"
            "This public dataset contains sampled picks by tier, not every answer the live game accepts."
        )

    def search(self):
        query = self.prompt.get("1.0", "end").strip()
        if not query:
            messagebox.showinfo("Enter a prompt", "Paste the full Krillion prompt first.")
            return
        self.result.delete("1.0", "end")
        try:
            results = find_candidates(query)
        except Exception as exc:
            messagebox.showerror("Database error", str(exc))
            return
        if not results:
            self.result.insert("end", "NO HISTORICAL MATCH FOUND\n\n")
            self.result.insert("end", "This prompt may be new or worded differently. "
                "The database will not invent an answer. Try adding the full category and its restrictions.")
            return

        best = results[0]
        if best["similarity"] < 0.35:
            self.result.insert("end", "WEAK PROMPT MATCH\n", "tier")
            self.result.insert("end", "These are from prompts that may only be loosely related. "
                "Do not treat them as valid for your current question.\n\n", "muted")
        else:
            self.result.insert("end", "TOP RECORDED CANDIDATE\n", "tier")
            self.result.insert("end", best["answer"] + "\n", "best")
            self.result.insert("end",
                f'{best["tier"]} · {best["points"]} points in the historical sheet\n'
                f'Prompt match: {best["similarity"]:.0%} · Source dive #{best["dive"]} ({best["date"]})\n\n',
                "muted")
        self.result.insert("end", "OTHER RECORDED PICKS\n", "tier")
        for i, item in enumerate(results, 1):
            self.result.insert("end", f'{i}. {item["answer"]}  —  {item["tier"]} ({item["points"]} pts)\n')
            self.result.insert("end",
                f'   From: "{item["prompt"]}" · match {item["similarity"]:.0%} · {item["date"]}\n',
                "muted")
        self.result.insert("end",
            "\nIMPORTANT: These are historical sampled answers, not a live validation of today's prompt. "
            "A high historical tier does not guarantee the current game will accept the answer.")
        self.last_best = best["answer"] if best["similarity"] >= 0.35 else ""

    def copy_top(self):
        answer = getattr(self, "last_best", "")
        if not answer:
            messagebox.showinfo("Nothing to copy", "There is no strong top match to copy.")
            return
        self.root.clipboard_clear()
        self.root.clipboard_append(answer)
        self.status.set("Copied: " + answer)

    def clear(self):
        self.prompt.delete("1.0", "end")
        self.result.delete("1.0", "end")
        self.last_best = ""
        self.status.set("Ready.")

    def scan_screen(self):
        try:
            import mss
            from PIL import Image, ImageTk
            import pytesseract
        except ImportError:
            messagebox.showerror(
                "OCR packages missing",
                "For screen scanning, install the optional packages:\n"
                "pip install mss pillow pytesseract\n\n"
                "You also need Tesseract OCR installed on Windows. "
                "You can still paste prompts manually without OCR."
            )
            return
        try:
            with mss.mss() as sct:
                mon = sct.monitors[1]
                shot = sct.grab(mon)
                img = Image.frombytes("RGB", shot.size, shot.rgb)
        except Exception as exc:
            messagebox.showerror("Screen capture failed", str(exc))
            return

        picker = tk.Toplevel(self.root)
        picker.title("Select the prompt area")
        picker.attributes("-topmost", True)
        max_w, max_h = 1150, 740
        scale = min(max_w / img.width, max_h / img.height, 1)
        shown = img.resize((int(img.width * scale), int(img.height * scale)))
        photo = ImageTk.PhotoImage(shown)
        canvas = tk.Canvas(picker, width=shown.width, height=shown.height,
                           cursor="cross", highlightthickness=0)
        canvas.pack()
        canvas.create_image(0, 0, image=photo, anchor="nw")
        canvas.image = photo
        state = {"start": None, "rect": None}

        def down(event):
            state["start"] = (event.x, event.y)
            if state["rect"]:
                canvas.delete(state["rect"])
            state["rect"] = canvas.create_rectangle(event.x, event.y, event.x, event.y,
                                                      outline="#ff4545", width=3)
        def drag(event):
            if state["start"] and state["rect"]:
                canvas.coords(state["rect"], *state["start"], event.x, event.y)
        def up(event):
            if not state["start"]:
                return
            x1, y1 = state["start"]
            x2, y2 = event.x, event.y
            left, top = min(x1, x2), min(y1, y2)
            right, bottom = max(x1, x2), max(y1, y2)
            if right-left < 12 or bottom-top < 12:
                return
            crop = img.crop((int(left/scale), int(top/scale),
                             int(right/scale), int(bottom/scale)))
            try:
                text = pytesseract.image_to_string(crop).strip()
                if text:
                    self.prompt.delete("1.0", "end")
                    self.prompt.insert("1.0", text)
                    self.status.set("OCR captured. Check the prompt, then click Find answers.")
                else:
                    self.status.set("No text recognised. Try selecting a larger area.")
            except Exception as exc:
                messagebox.showerror("OCR failed", str(exc))
            picker.destroy()
        canvas.bind("<ButtonPress-1>", down)
        canvas.bind("<B1-Motion>", drag)
        canvas.bind("<ButtonRelease-1>", up)
        ttk.Label(picker, text="Drag around only the prompt text.").pack(pady=5)

if __name__ == "__main__":
    root = tk.Tk()
    app = KrillionApp(root)
    root.mainloop()
