@echo off
py -m pip install --upgrade pip
py -m pip install mss pillow pytesseract
if errorlevel 1 (
  echo Optional OCR install failed. Manual prompt entry will still work.
)
pause
